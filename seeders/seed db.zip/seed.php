<?php

require_once 'seeders/DatabaseSeeder.php';


// run it with:  php seed.php

// Advantages of this approach
// ✅ One CsvSeeder works for every table.
// ✅ Automatically reads column names from the CSV header.
// ✅ Converts empty strings to NULL.
// ✅ Uses prepared statements (safe and efficient).
// ✅ Wraps each CSV import in a transaction.
// ✅ No need to modify the seeder when columns change—just update the CSV header.
// ✅ Child seeders remain extremely small, for example: