<?php

require_once 'CsvSeeder.php';

class ChildSeeder extends CsvSeeder
{
    public function run(): void
    {
        $this->seed(
            'district',
            __DIR__ . '/../csv/district.csv'
        );
    }
}
