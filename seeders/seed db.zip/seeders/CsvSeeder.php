<?php

require_once __DIR__ . '/../Database.php';

abstract class CsvSeeder
{
    protected PDO $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    abstract public function run(): void;

    protected function seed(string $table, string $csvFile): void
    {
        if (!file_exists($csvFile)) {
            throw new Exception("CSV file not found: {$csvFile}");
        }

        $handle = fopen($csvFile, 'r');

        if ($handle === false) {
            throw new Exception("Unable to open {$csvFile}");
        }

        $columns = fgetcsv($handle);

        if ($columns === false) {
            fclose($handle);
            return;
        }

        $placeholders = implode(',', array_fill(0, count($columns), '?'));

        $quotedColumns = implode(
            ',',
            array_map(fn($c) => "`{$c}`", $columns)
        );

        $sql = "INSERT INTO `{$table}` ({$quotedColumns})
                VALUES ({$placeholders})";

        $statement = $this->db->prepare($sql);

        $count = 0;

        $this->db->beginTransaction();

        try {

            while (($row = fgetcsv($handle)) !== false) {

                foreach ($row as &$value) {

                    if ($value === '') {
                        $value = null;
                    }
                }

                $statement->execute($row);

                $count++;
            }

            $this->db->commit();

        } catch (Exception $e) {

            $this->db->rollBack();

            fclose($handle);

            throw $e;
        }

        fclose($handle);

        echo "{$table} : {$count} rows inserted." . PHP_EOL;
    }
}